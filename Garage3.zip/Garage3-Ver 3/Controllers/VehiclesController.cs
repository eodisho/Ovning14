﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Garage3.Data;
using Garage3.Models;
using Garage3.Views.ViewModels;

namespace Garage3.Controllers
{
    public class VehiclesController : Controller
    {
        private readonly Garage3Context _context;

        public VehiclesController(Garage3Context context)
        {
            _context = context;
        }

        // GET: Vehicles
        public async Task<IActionResult> Index()
        {
            // Use a viewmodel here instead of the entity
            // Remove Make and Model, add vehicletype and member
            var allVehicles = await _context.Vehicle
                .Include(v => v.Member)
                .Include(v => v.VehicleType)
                // For each vehcicle that we got from the preivous statement we transform it below
                .Select(v => new ParkedVehicleViewModel
                {
                    Id = v.Id,
                    MemberId = v.Member.Id,
                    RegistrationNr = v.RegistrationNr,
                    VehicleTypeId = v.VehicleType.Id,
                    MemberName = v.Member.FirstName,
                    VehicleType = v.VehicleType.VehicleTypeName
                })
                .ToListAsync();

            //var model = allVehicles.Select(v => new ParkedVehicleViewModel
            //{
            //    Id = v.Id,
            //    MemberId = v.Member.Id,
            //    RegistrationNr = v.RegistrationNr,
            //    VehicleTypeId = v.VehicleType.Id,
            //    MemberName = v.Member.FirstName,
            //    VehicleType = v.VehicleType.VehicleTypeName
            //}).ToList();

            return View(allVehicles);
        }

        // GET: Vehicles/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vehicle = await _context.Vehicle
                .FirstOrDefaultAsync(m => m.Id == id);
            if (vehicle == null)
            {
                return NotFound();
            }

            return View(vehicle);
        }

        // GET: Vehicles/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Vehicles/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateVehicleViewModel viewVehicle)
        {
            if (ModelState.IsValid)
            {
                var vehicle = new Vehicle
                {
                    ArrivalTime = viewVehicle.ArrivalTime,
                    Make = viewVehicle.Make,
                    Model = viewVehicle.Model,
                    NrOfWheels = viewVehicle.NrOfWheels,
                    RegistrationNr = viewVehicle.RegistrationNr,
                    Garage = _context.Garage.FirstOrDefault(g => g.Id == 1),
                    // The first intity we find that fullfils the lambda expression so that 
                    // the member id matches the id from the veiw model. 
                    Member = _context.Member.FirstOrDefault(m => m.Id == viewVehicle.MemberId),
                    VehicleType = _context.VehicleType.FirstOrDefault(vt => vt.Id == viewVehicle.VehicleTypeId)
                };


                _context.Add(vehicle);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(viewVehicle);
        }

        // GET: Vehicles/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vehicle = await _context.Vehicle.FindAsync(id);
            if (vehicle == null)
            {
                return NotFound();
            }
            return View(vehicle);
        }

        // POST: Vehicles/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,RegistrationNr,Make,Model,NrOfWheels,ArrivalTime")] Vehicle vehicle)
        {
            if (id != vehicle.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(vehicle);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VehicleExists(vehicle.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(vehicle);
        }

        // GET: Vehicles/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vehicle = await _context.Vehicle
                .FirstOrDefaultAsync(m => m.Id == id);
            if (vehicle == null)
            {
                return NotFound();
            }

            return View(vehicle);
        }

        // POST: Vehicles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var vehicle = await _context.Vehicle.FindAsync(id);
            _context.Vehicle.Remove(vehicle);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool VehicleExists(int id)
        {
            return _context.Vehicle.Any(e => e.Id == id);
        }
    }
}
