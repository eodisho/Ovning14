﻿using Garage3.Data;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Garage3.Services
{
    public class SelectVehicleType
    {
        private readonly Garage3Context db;

        public SelectVehicleType(Garage3Context PassedInDb)
        {
            db = PassedInDb;
        }

        // We are returning IEnumerable, It enumerate the SelectedListItem 
        // and returns it as a list
        public async Task<IEnumerable<SelectListItem>> SelectTypes()
        {
            var Vtype = await db.VehicleType.Select(vt => new SelectListItem
            {
                Text = vt.VehicleTypeName,

                Value = vt.Id.ToString()
            }).ToListAsync();
            // this list will be used to inject values into the view. 
            return Vtype;
        }
       

    }
}
