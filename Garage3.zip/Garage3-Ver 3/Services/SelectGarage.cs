﻿using Garage3.Data;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Garage3.Services
{
    public class SelectGarage
    {
        private readonly Garage3Context db;
        public SelectGarage(Garage3Context PassedInDB)
        {
            db = PassedInDB;
        }

        public async Task<IEnumerable<SelectListItem>> SelectAllGarage()
        {
            var allGarageId = await db.Garage.Select(am => new SelectListItem
            {
                Text = $"{am.Id}",

                Value = am.Id.ToString()
            }).ToListAsync();
            return allGarageId;
        } 
    }
}

