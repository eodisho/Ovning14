﻿using Garage3.Data;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace Garage3.Services
{
    public class SelectMembers
    {
        private readonly Garage3Context db;
        public SelectMembers(Garage3Context PassedInDB)
        {
            db = PassedInDB;
        }

        // We are returning IEnumerable, It enumerate the SelectedListItem 
        // and returns it as a list
        public async Task<IEnumerable<SelectListItem>> SelectAllMembers()
        {
            var allMembers = await db.Member.Select(am => new SelectListItem
            {
                Text = $"{am.FirstName} {am.LastName}",
               
                Value = am.Id.ToString()
            }).ToListAsync();
            // this list will be used to inject values into the view. 
            return allMembers;
        }

    }
}
