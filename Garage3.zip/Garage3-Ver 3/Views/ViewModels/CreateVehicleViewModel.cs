﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Garage3.Views.ViewModels
{
    public class CreateVehicleViewModel
    {
       
        public string RegistrationNr { get; set; }

        public string Make { get; set; }
        public string Model { get; set; }

        public int NrOfWheels { get; set; }
        public DateTime ArrivalTime { get; set; }

        // Navigation properties for FK's, e.g. A vehicle can have only one owner
        public int MemberId { get; set; }
        public int VehicleTypeId { get; set; }
        public int GarageId { get; set; }
    }
}
