﻿using Garage3.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Garage3.Views.ViewModels
{
    public class ParkedVehicleViewModel
    {
        public int Id { get; set; }
        public string RegistrationNr { get; set; }

        // Navigation properties for FK's, e.g. A vehicle can have only one owner
        public int MemberId { get; set; }
        public int VehicleTypeId { get; set; }

        public string VehicleType { get; set; }
        public string MemberName { get; set; }



    }
}
